# Rewear Outlet Multan
app/www = customer app, admin/ = admin panel, data/ = products/banners/settings.
APK: GitHub > Actions > Build APK > Run workflow > artifact "rewear-outlet-apk".
